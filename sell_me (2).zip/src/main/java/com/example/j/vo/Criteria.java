package com.example.j.vo;

import lombok.Data;

@Data
public class Criteria {
    private String searchType;
    private String searchKeyword;
}
