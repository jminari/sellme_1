package com.example.j.vo;

import lombok.Data;

@Data
public class companyVO {
    private String comNum;
    private String comName;
    private String comType;
    private String comCeo;
    private String comAddress;
}
